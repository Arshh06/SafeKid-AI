"""Scratch benchmark script to test CPU optimizations for YOLOv8n and pipeline components."""

import time
import cv2
import numpy as np
import torch
import ultralytics.nn.tasks as tasks
from ultralytics import YOLO

def test_yolo_optimizations():
    print("=" * 60)
    print("TESTING YOLOv8n CPU OPTIMIZATIONS")
    print("=" * 60)
    
    orig_safe_load = tasks.torch_safe_load
    tasks.torch_safe_load = lambda weight: (torch.load(weight, map_location="cpu", weights_only=False), weight)
    try:
        model = YOLO("yolov8n.pt")
    finally:
        tasks.torch_safe_load = orig_safe_load
    
    # Create test 1080p frame (1920x1080x3)
    frame_1080p = np.zeros((1080, 1920, 3), dtype=np.uint8)
    cv2.rectangle(frame_1080p, (500, 300), (600, 700), (200, 200, 200), -1)

    # Warmup
    for _ in range(5):
        _ = model.predict(source=frame_1080p, classes=[0], verbose=False)
        
    # Baseline: 15 iterations on 1080p
    times_baseline = []
    for _ in range(15):
        t0 = time.perf_counter()
        res = model.predict(source=frame_1080p, classes=[0], verbose=False)
        times_baseline.append((time.perf_counter() - t0) * 1000)
    print(f"Baseline (no fuse, default imgsz) 1080p: {np.mean(times_baseline):.2f} ms")

    # Test explicit imgsz=640 vs 480 vs 384
    for sz in [640, 480, 384]:
        times_sz = []
        for _ in range(15):
            t0 = time.perf_counter()
            res = model.predict(source=frame_1080p, imgsz=sz, classes=[0], verbose=False)
            times_sz.append((time.perf_counter() - t0) * 1000)
        print(f"Explicit imgsz={sz} on 1080p: {np.mean(times_sz):.2f} ms")

    # Test model.fuse()
    print("Fusing model layers...")
    try:
        model.fuse()
        print("Model fused successfully.")
    except Exception as e:
        print(f"Fuse failed: {e}")

    times_fused = []
    for _ in range(15):
        t0 = time.perf_counter()
        res = model.predict(source=frame_1080p, imgsz=640, classes=[0], verbose=False)
        times_fused.append((time.perf_counter() - t0) * 1000)
    print(f"Fused model (imgsz=640) on 1080p: {np.mean(times_fused):.2f} ms")

    # Test torch threads
    curr_threads = torch.get_num_threads()
    for n_threads in [2, 4, 6, 8]:
        torch.set_num_threads(n_threads)
        times_threads = []
        for _ in range(10):
            t0 = time.perf_counter()
            res = model.predict(source=frame_1080p, imgsz=640, classes=[0], verbose=False)
            times_threads.append((time.perf_counter() - t0) * 1000)
        print(f"Threads={n_threads}: {np.mean(times_threads):.2f} ms")
    torch.set_num_threads(curr_threads)

    # Test tracking with ByteTrack
    tracker_yaml = "bytetrack.yaml"
    times_track = []
    for _ in range(15):
        t0 = time.perf_counter()
        res = model.track(source=frame_1080p, persist=True, tracker=tracker_yaml, classes=[0], imgsz=640, verbose=False)
        times_track.append((time.perf_counter() - t0) * 1000)
    print(f"Fused model track() with imgsz=640: {np.mean(times_track):.2f} ms")

if __name__ == "__main__":
    test_yolo_optimizations()
