import json
from pathlib import Path

events_path = Path("outputs/pool_safety_events.json")
if events_path.exists():
    with open(events_path, "r") as f:
        data = json.load(f)

    print("Metadata:", data.get("metadata"))
    tracks = set(e["track_id"] for e in data.get("events", []) if e.get("track_id") is not None)
    print("Tracks with events:", sorted(tracks))
    for tid in sorted(tracks):
        t_evts = [e for e in data.get("events", []) if e.get("track_id") == tid]
        print(f"Track {tid}:")
        for e in t_evts:
            print(f"  [{e['timestamp_seconds']:.2f}s | Frame {e['frame_id']}] {e['event_type']} in {e['zone_name']} - {e['message']}")

