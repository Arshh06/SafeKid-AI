import sys
from pathlib import Path
SRC_DIR = Path(__file__).resolve().parent.parent / "src"
if str(SRC_DIR) not in sys.path:
    sys.path.insert(0, str(SRC_DIR))

import cv2
import json

# Let's inspect each track ID, save a sample crop from the video to scratch/crops/
video_path = "data/demo/pool_safety_demo.mp4"
cap = cv2.VideoCapture(video_path)

crops_dir = Path("scratch/crops")
crops_dir.mkdir(parents=True, exist_ok=True)

# Let's run tracker or detector briefly or read detections
from safekid_ai.detector import PersonDetector
from safekid_ai.tracker import PersonTracker
from safekid_ai.config import DetectorConfig, TrackerConfig

detector = PersonDetector(DetectorConfig())
tracker = PersonTracker(detector.model, TrackerConfig())

saved_tracks = set()

frame_id = 0
while cap.isOpened():
    ret, frame = cap.read()
    if not ret:
        break
    
    dets = tracker.track(frame, frame_id=frame_id, timestamp_ms=frame_id * 1000.0 / 24.0)
    for det in dets.detections:
        tid = det.track_id
        if tid is not None and tid not in saved_tracks:
            # save crop
            x1, y1, x2, y2 = map(int, det.bbox_xyxy)
            crop = frame[max(0, y1):min(frame.shape[0], y2), max(0, x1):min(frame.shape[1], x2)]
            if crop.size > 0:
                cv2.imwrite(str(crops_dir / f"track_{tid}_f{frame_id}.jpg"), crop)
                saved_tracks.add(tid)
                print(f"Saved track {tid} at frame {frame_id}, bbox: {det.bbox_xyxy}")

    frame_id += 1

cap.release()
print(f"Saved sample crops for tracks: {sorted(saved_tracks)}")
