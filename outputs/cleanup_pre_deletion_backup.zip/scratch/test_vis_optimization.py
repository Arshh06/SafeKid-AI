"""Test visualization sub-bounding-box optimization."""

import time
import cv2
import numpy as np

def test_vis():
    h, w = 1080, 1920
    frame = np.random.randint(0, 255, (h, w, 3), dtype=np.uint8)
    
    # 3 polygons typical of 1080p camera
    poly1 = np.array([[100, 200], [600, 200], [600, 800], [100, 800]], dtype=np.int32)
    poly2 = np.array([[700, 300], [1200, 300], [1200, 900], [700, 900]], dtype=np.int32)
    poly3 = np.array([[1300, 100], [1800, 100], [1800, 500], [1300, 500]], dtype=np.int32)
    polys = [poly1, poly2, poly3]
    colors = [(0, 255, 0), (0, 255, 255), (0, 0, 255)]
    alphas = [0.16, 0.20, 0.24]

    # Baseline: full-frame copy + addWeighted per polygon
    times_base = []
    for _ in range(30):
        vis = frame.copy()
        t0 = time.perf_counter()
        for poly, color, alpha in zip(polys, colors, alphas):
            zone_overlay = vis.copy()
            cv2.fillPoly(zone_overlay, [poly], color)
            cv2.addWeighted(zone_overlay, alpha, vis, 1.0 - alpha, 0, vis)
        times_base.append((time.perf_counter() - t0) * 1000)
    print(f"Baseline full-frame zone fills (3 zones, 1080p): {np.mean(times_base):.2f} ms")

    # Optimized: sub-bounding-box blend
    times_opt = []
    for _ in range(30):
        vis = frame.copy()
        t0 = time.perf_counter()
        for poly, color, alpha in zip(polys, colors, alphas):
            bx, by, bw, bh = cv2.boundingRect(poly)
            # clamp to frame
            bx1 = max(0, bx)
            by1 = max(0, by)
            bx2 = min(w, bx + bw)
            by2 = min(h, by + bh)
            sub_vis = vis[by1:by2, bx1:bx2]
            sub_overlay = sub_vis.copy()
            poly_offset = poly - [bx1, by1]
            cv2.fillPoly(sub_overlay, [poly_offset], color)
            cv2.addWeighted(sub_overlay, alpha, sub_vis, 1.0 - alpha, 0, sub_vis)
        times_opt.append((time.perf_counter() - t0) * 1000)
    print(f"Optimized sub-bounding-box zone fills (3 zones, 1080p): {np.mean(times_opt):.2f} ms")

if __name__ == "__main__":
    test_vis()

